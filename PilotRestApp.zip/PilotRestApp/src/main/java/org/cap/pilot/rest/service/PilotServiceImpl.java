package org.cap.pilot.rest.service;

import java.util.List;

import org.cap.pilot.rest.dao.PilotDao;
import org.cap.pilot.rest.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Transactional
@Service("pilotService")
public class PilotServiceImpl implements PilotService{
	
	@Autowired
	private PilotDao pilotDao;

	@Override
	public void save(Pilot pilot) {
		
		pilotDao.save(pilot);
	}

	@Override
	public List<Pilot> getAll() {
		
		return pilotDao.findAll();
	}

	@Override
	public void delete(Integer pilotId) {
		pilotDao.deleteById(pilotId);
		
	}

	/*@Override
	public void update(Integer pilotId) {
		// TODO Auto-generated method stub
		pilotDao.editById(pilotId);
	}
	*/

}
