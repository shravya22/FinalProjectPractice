package paymentForm;


import static org.junit.Assert.assertTrue;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Page.paymentPageBean;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {
	private WebDriver driver;
	private paymentPageBean paymentPageBean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		 driver=new ChromeDriver();
		 paymentPageBean=new paymentPageBean(driver);
		driver.get("http://localhost:8083/StudentRegForm/next");
	}
	/*@Given("^open student registration form$")
	public void open_student_registration_form() throws Throwable {
			
	}

	@When("^valid student details$")
	public void valid_student_details() throws Throwable {
		studentPageBean.navigateTo_NextPage("Tom", "Jerry", "asfsdfsdg", "Hyderabad", "Telangana", "female", "ME","1234567890");
	}

	@Then("^navigate to payment form$")
	public void navigate_to_payment_form() throws Throwable {
	   driver.switchTo().alert().accept();
	   String url=driver.getCurrentUrl();
	   assertTrue(url.equals("http://localhost:8083/StudentRegForm/next"));
	}*/
	@Given("^open payment form$")
	public void open_payment_form() throws Throwable {
		driver.get("http://localhost:8083/StudentRegForm/next");
	}

	@When("^valid payment details$")
	public void valid_payment_details() throws Throwable {
		paymentPageBean.navigateTo_NextPage("SAI", "1234567890123456", "123", "11/18");
	}

	@Then("^navigate to student form$")
	public void navigate_to_student_form() throws Throwable {
		 driver.switchTo().alert().accept();
		   String url=driver.getCurrentUrl();
		   assertTrue(url.equals("http://localhost:8083/StudentRegForm/"));
	}

	/*@After
	public void tearDown() {
		driver.close();
	}*/
}
