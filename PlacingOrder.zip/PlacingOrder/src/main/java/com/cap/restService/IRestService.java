package com.cap.restService;

import java.util.List;

import com.cap.model.Inventory;
import com.cap.model.Order;
import com.cap.model.Transaction;

public interface IRestService {

		

		public List<Inventory> checkAll();

		

		public void save(Inventory inventory);  //ARCHANA

		/*public void save1(Order order);

		public void save2(Order order);*/
}
