package org.cap.dao;

import java.util.List;

import org.cap.model.LoginPilot;
import org.cap.model.Pilot;

public interface PilotDAO {
public void save(Pilot pilot);
public List<Pilot> getAll();
public void delete(Integer pilotId);
public List<LoginPilot> getAllPilots();
public Pilot findPilot(Integer pilotId);
public void update(Pilot pilot1);

}
