package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.LoginPilot;
import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("PilotDAO")

public class PilotDAOImp implements PilotDAO{

	@PersistenceContext
	private EntityManager em;
	@Transactional
	@Override
	public void save(Pilot pilot) {
		// TODO Auto-generated method stub
		em.persist(pilot);
	}
	@Transactional(readOnly=true)
	@Override
	
	public List<Pilot> getAll() {
		// TODO Auto-generated method stub
		List<Pilot> pilots=em.createQuery("from Pilot").getResultList();
		return pilots;
	}
	
	@Transactional
	@Override
	public void delete(Integer pilotId) {
		// TODO Auto-generated method stub
		Pilot pilot=em.find(Pilot.class, pilotId);
		em.remove(pilot);
	}
	@Transactional
	@Override
	public List<LoginPilot> getAllPilots() {
		List<LoginPilot> pilots1=em.createQuery("from LoginPilot").getResultList();
		return pilots1;
	}
	@Transactional
	@Override
	public Pilot findPilot(Integer pilotId) {
		Pilot pilot=em.find(Pilot.class, pilotId);
		return pilot;
	}
	@Transactional
	@Override
	public void update(Pilot pilot1) {
		// TODO Auto-generated method stub
		if(pilot1.getPilotId()!=0)
			em.merge(pilot1);
		else
			em.persist(pilot1);
		
	}

}
