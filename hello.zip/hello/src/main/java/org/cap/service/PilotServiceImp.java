package org.cap.service;

import java.util.List;

import org.cap.dao.PilotDAO;
import org.cap.model.LoginPilot;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("PilotService")
public class PilotServiceImp implements PilotService {
@Autowired
private PilotDAO pilotDao;
	@Override
	public void save(Pilot pilot) {
		// TODO Auto-generated method stub
		pilotDao.save(pilot);
	}
	@Override
	public List<Pilot> getAll() {
		// TODO Auto-generated method stub
		return pilotDao.getAll();
	}
	@Override
	public void delete(Integer pilotId) {
		// TODO Auto-generated method stub
		pilotDao.delete(pilotId);
	}
	@Override
	public List<LoginPilot> getAllPilots() {
		// TODO Auto-generated method stub
		return pilotDao.getAllPilots();
	}
	@Override
	public Pilot findPilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return pilotDao.findPilot(pilotId);
	}
	@Override
	public void update(Pilot pilot1) {
		pilotDao.update(pilot1);
		
	}
	
}
