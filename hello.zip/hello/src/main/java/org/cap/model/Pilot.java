package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
@Entity
public class Pilot {
@Id
@GeneratedValue
private int pilotId;
@NotEmpty(message="Please Enter Firstname")
private String firstName;
private String lastName;
@Past(message="Please Enter past date")
@NotNull(message="Please Enter Correct date")
private Date DOB;
@Future(message="Please Enter future date")
@NotNull(message="Please Enter Correct date")
private Date DOJ;
private boolean isCertified;
@Range(min=10000,max=200000,message="enter in range")
private double salary;
public int getPilotId() {
	return pilotId;
}
public void setPilotId(int pilotId) {
	this.pilotId = pilotId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public Date getDOB() {
	return DOB;
}
public void setDOB(Date dOB) {
	DOB = dOB;
}
public Date getDOJ() {
	return DOJ;
}
public void setDOJ(Date dOJ) {
	DOJ = dOJ;
}
public boolean getIsCertified() {
	return isCertified;
}
public void setIsCertified(boolean isCertified) {
	this.isCertified = isCertified;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", DOB=" + DOB
			+ ", DOJ=" + DOJ + ", isCertified=" + isCertified + ", salary=" + salary + "]";
}
public Pilot(int pilotId, String firstName, String lastName, Date dOB, Date dOJ, boolean isCertified, double salary) {
	super();
	this.pilotId = pilotId;
	this.firstName = firstName;
	this.lastName = lastName;
	DOB = dOB;
	DOJ = dOJ;
	this.isCertified = isCertified;
	this.salary = salary;
}
public Pilot()
{
	
}


}
