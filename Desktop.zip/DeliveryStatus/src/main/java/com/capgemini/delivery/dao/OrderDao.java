package com.capgemini.delivery.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.delivery.model.ManagingCart;
import com.capgemini.delivery.model.Order;

@Repository("orderDao")
public interface OrderDao extends JpaRepository<Order,Integer> {
	@Query("select cartId,quantity from ManagingCart where order_id=:id")
	List<ManagingCart> findByOrderId(int id);

	
}
