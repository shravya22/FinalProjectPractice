package com.capgemini.delivery.service;

import java.util.List;

import com.capgemini.delivery.model.ManagingCart;
import com.capgemini.delivery.model.Order;


public interface OrderService {
	public void save(Order feedback);
	public List<Order> getAll();
	public Order getOne(Integer feedbackId);
	public void delete(Integer fid);
	public List<ManagingCart> findByOrderId(int id);
	
}
