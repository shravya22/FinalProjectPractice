package status;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^Delivery status$")
	public void delivery_status() throws Throwable {
	   
	}

	@When("^Delivery status is not delivered$")
	public void delivery_status_is_not_delivered() throws Throwable {
	 
	}

	@Then("^Update the inventory quantity by incrementing the value$")
	public void update_the_inventory_quantity_by_incrementing_the_value() throws Throwable {
	    
	}

	@When("^Delivery status is delivered$")
	public void delivery_status_is_delivered() throws Throwable {
	    
	}

	@Then("^Update the delivered date$")
	public void update_the_delivered_date() throws Throwable {
	    
	}
}
