package org.cap.pilot.model;

import java.util.Date;


import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import com.fasterxml.jackson.annotation.JsonFormat;


public class Pilot {

	private int pilotId;
	@NotEmpty(message="*please enter firstName.")
	private String firstName;
	private String lastName;
	
	
	@Past(message="* Please enter past date.")
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date dob;
	
	@Future(message="* Please nter future date.")
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date doj;
	private Boolean isCertified;
	
	@Range(min=10000,max=200000,message="*Salary should be between 10000 and 2laks.")
	private double salary;
	
	public Pilot() {
		
	}

	public int getPilotId() {
		return pilotId;
	}

	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public Boolean getIsCertified() {
		return isCertified;
	}

	public void setIsCertified(Boolean isCertified) {
		this.isCertified = isCertified;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dob=" + dob
				+ ", doj=" + doj + ", isCertified=" + isCertified + ", salary=" + salary + "]";
	}

	public Pilot(int pilotId, @NotEmpty(message = "*please enter firstName.") String firstName, String lastName,
			@NotNull(message = "* Please enter Date Of Birth.") @Past(message = "* Please enter past date.") Date dob,
			@Future(message = "* Please nter future date.") Date doj, Boolean isCertified,
			@Range(min = 10000, max = 200000, message = "*Salary should be between 10000 and 2laks.") double salary) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.doj = doj;
		this.isCertified = isCertified;
		this.salary = salary;
	}
	

	

}
