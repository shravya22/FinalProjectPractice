package update;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^Delivery status$")
	public void delivery_status() throws Throwable {
	   
	}

	@When("^Status is not delivered$")
	public void status_is_not_delivered() throws Throwable {
	    
	}

	@Then("^Update the inventory by incrementing the stock$")
	public void update_the_inventory_by_incrementing_the_stock() throws Throwable {
	    
	}

	@When("^Status is delivered$")
	public void status_is_delivered() throws Throwable {
	   
	}

	@Then("^Update the delivered date in order table$")
	public void update_the_delivered_date_in_order_table() throws Throwable {
	    
	}

}
