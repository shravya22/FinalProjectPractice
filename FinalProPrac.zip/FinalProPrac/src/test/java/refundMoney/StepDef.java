package refundMoney;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^returnId,customerId,productId$")
	public void returnid_customerId_productId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^product is valid for refund$")
	public void product_is_valid_for_refund() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^money is refunded$")
	public void money_is_refunded() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^product is not valid for refund$")
	public void product_is_not_valid_for_refund() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^status is changed to NOT REFUNDABLE in the return orders table$")
	public void status_is_changed_to_NOT_REFUNDABLE_in_the_return_orders_table() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
