package com.cap.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.service.IUpdateService;
import com.mysql.fabric.Response;

@RestController
//@RequestMapping("/api/v1")
public class Controller {

	@Autowired
	private IUpdateService updateService;
	
	/*@GetMapping("/pilots")
	public ResponseEntity<List<Pilot>> getAllPilots(){
		List<Pilot> pilots= pilotService.getAll();
		if(pilots.isEmpty()||pilots==null)
			return new ResponseEntity
				("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Pilot>>(pilots,HttpStatus.OK);
	}
	
	
	@PostMapping("/pilots")
	public ResponseEntity<Pilot> createPilot(@RequestBody Pilot pilot){
		pilotService.save(pilot);
		
		return new ResponseEntity<Pilot>(pilot,HttpStatus.OK);
	}
	
	
	@DeleteMapping("/pilots/{pilotId}")
	public void deletePilot(@PathVariable("pilotId") Integer pilotId) {
		
		pilotService.delete(pilotId);
		
	}*/
	
	/*@PutMapping("/pilots/{pilotId}")
	public void updatePilot(@PathVariable("pilotId") Integer pilotId) {
		
		//pilotService.update(pilotId);
		
	}*/
	
	
	
}
