package com.cap.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cap.model.OrderDetails;

import com.cap.service.UpdateServiceImp;
@Controller
public class Controller {
	@Autowired
	private UpdateServiceImp updateservice;
	OrderDetails status=new OrderDetails();
	@RequestMapping("/save")
	public String updateStatus()
	{
		System.out.println("Hello");
		status.setOrderId(104);
		status.setDeliveryStatus("delivered");
		Date date=new Date();
		updateservice.update(date);
		return "redirect:/";
	}
}
