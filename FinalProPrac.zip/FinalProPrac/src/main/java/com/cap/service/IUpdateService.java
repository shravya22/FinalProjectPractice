package com.cap.service;

import java.util.Date;

public interface IUpdateService {
	public void update(Date date);
}
