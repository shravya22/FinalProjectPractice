package com.cap.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.IUpdateDao;
@Service("updateservice")
public class UpdateServiceImp implements IUpdateService{
	@Autowired
	private IUpdateDao updatedao;

	@Override
	public void update(Date date) {
		updatedao.update(date);
	}



}
