package com.cap.model;

public class ReturnOrders {
private int returnId;
private int customerId;
private Boolean merchantValidation;
private int transactionId;
private int productId;
public int getReturnId() {
	return returnId;
}
public void setReturnId(int returnId) {
	this.returnId = returnId;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public Boolean getMerchantValidation() {
	return merchantValidation;
}
public void setMerchantValidation(Boolean merchantValidation) {
	this.merchantValidation = merchantValidation;
}
public int getTransactionId() {
	return transactionId;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public ReturnOrders(int returnId, int customerId, Boolean merchantValidation, int transactionId, int productId) {
	super();
	this.returnId = returnId;
	this.customerId = customerId;
	this.merchantValidation = merchantValidation;
	this.transactionId = transactionId;
	this.productId = productId;
}
public ReturnOrders() {

}
@Override
public String toString() {
	return "ReturnOrders [returnId=" + returnId + ", customerId=" + customerId + ", merchantValidation="
			+ merchantValidation + ", transactionId=" + transactionId + ", productId=" + productId + "]";
}




}
