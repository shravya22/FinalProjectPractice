package com.cap.model;

public class Bank {
private int customerId;
private long accountNo;
private long cardNo;
private double balance;
private int  pinNo;
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public long getCardNo() {
	return cardNo;
}
public void setCardNo(long cardNo) {
	this.cardNo = cardNo;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public int getPinNo() {
	return pinNo;
}
public void setPinNo(int pinNo) {
	this.pinNo = pinNo;
}
public Bank(int customerId, long accountNo, long cardNo, double balance, int pinNo) {
	super();
	this.customerId = customerId;
	this.accountNo = accountNo;
	this.cardNo = cardNo;
	this.balance = balance;
	this.pinNo = pinNo;
}
public Bank() {

}
@Override
public String toString() {
	return "Bank [customerId=" + customerId + ", accountNo=" + accountNo + ", cardNo=" + cardNo + ", balance=" + balance
			+ ", pinNo=" + pinNo + "]";
}


}
