package com.cap.dao;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository("updatedao")
@Transactional
public class UpdateDaoImp implements IUpdateDao{
	@PersistenceContext
	private EntityManager entitymanager;
	@Override
	public void update(Date date) {
		// TODO Auto-generated method stub
		Query query= entitymanager.createQuery("UPDATE OrderDetails od SET od.deliveredDate = :date1 WHERE od.deliveryStatus =:status");
		query.setParameter("date1",date);
		query.setParameter("status","delivered");
	}

}
