package com.cap.dao;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.model.Order;


@Repository("updatedao")
public interface IUpdateDao extends JpaRepository<Order, Integer> {

	/*@Modifying
    @Query("UPDATE OrderDetails od SET od.deliveredDate = :date WHERE od.deliveryStatus = :delivered")
    int update(@Param("date") Date deliveredDate);
	*/
}
