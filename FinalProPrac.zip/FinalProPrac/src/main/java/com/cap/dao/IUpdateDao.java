package com.cap.dao;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cap.model.OrderDetails;

@Transactional
@Repository("updatedao")
public interface IUpdateDao {

	public void update(Date date);
	/*@Modifying
    @Query("UPDATE OrderDetails od SET od.deliveredDate = :date WHERE od.deliveryStatus = :delivered")
    int update(@Param("date") Date deliveredDate);*/
	
}
