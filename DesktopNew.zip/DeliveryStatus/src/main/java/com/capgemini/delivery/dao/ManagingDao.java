package com.capgemini.delivery.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.delivery.model.ManagingCart;
import com.capgemini.delivery.model.Order;
@Repository("managingDao")
public interface ManagingDao extends JpaRepository<ManagingCart,Integer> {
	@Query("select c.cartId,c.quantity,c.status,c.order.orderId from ManagingCart c where c.order.orderId = :id")
	List<ManagingCart> findcartbyid(@Param("id") Integer orderId);
}


