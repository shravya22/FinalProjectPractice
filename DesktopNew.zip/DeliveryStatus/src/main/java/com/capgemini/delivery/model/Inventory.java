package com.capgemini.delivery.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
public class Inventory {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	private String productName;
	private String description;
	
	
	
	private int noOfViews;
	private String Category;
	private Date dateOfInclusion;
	private double price;
	

	private int quantity;
	private Date expiryDate;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="managingCart")
	private ManagingCart managingCart;
	
	
	public Inventory() {
		
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getNoOfViews() {
		return noOfViews;
	}


	public void setNoOfViews(int noOfViews) {
		this.noOfViews = noOfViews;
	}


	public String getCategory() {
		return Category;
	}


	public void setCategory(String category) {
		Category = category;
	}


	public Date getDateOfInclusion() {
		return dateOfInclusion;
	}


	public void setDateOfInclusion(Date dateOfInclusion) {
		this.dateOfInclusion = dateOfInclusion;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public Date getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}


	public ManagingCart getManagingCart() {
		return managingCart;
	}


	public void setManagingCart(ManagingCart managingCart) {
		this.managingCart = managingCart;
	}


	@Override
	public String toString() {
		return "Inventory [productId=" + productId + ", productName=" + productName + ", description=" + description
				+ ", noOfViews=" + noOfViews + ", Category=" + Category + ", dateOfInclusion=" + dateOfInclusion
				+ ", price=" + price + ", quantity=" + quantity + ", expiryDate=" + expiryDate + ", managingCart="
				+ managingCart + "]";
	}


	public Inventory(int productId, String productName, String description, int noOfViews, String category,
			Date dateOfInclusion, double price, int quantity, Date expiryDate, ManagingCart managingCart) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.description = description;
		this.noOfViews = noOfViews;
		Category = category;
		this.dateOfInclusion = dateOfInclusion;
		this.price = price;
		this.quantity = quantity;
		this.expiryDate = expiryDate;
		this.managingCart = managingCart;
	}
	
}
