package login;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import page.LoginPageBean;

public class loginPageTest {

	private WebDriver driver;
	private LoginPageBean loginPageBean;
	
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\chromedriver.exe");
	
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		loginPageBean=new LoginPageBean(driver);
	}
	
	@Test
	public void  check_loginpage_naviagation() {
		driver.get("http://localhost:8081/WalletSpringJpa/");
		String pageHeading=loginPageBean.getPageTitle();
		
		assertTrue(pageHeading.equals("Banking Application"));

		
		loginPageBean.loginTo_NextPage("1", "siri1922");
		
	}
	
	
	@After
	public void tearDown() {
		//driver.close();
	}
}
