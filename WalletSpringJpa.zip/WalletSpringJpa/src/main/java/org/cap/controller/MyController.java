package org.cap.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.walletservice.AccountService;
import org.cap.walletservice.LoginService;
import org.cap.walletservice.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	@Autowired
	private LoginService loginService;
	@Autowired 
	private AccountService acctService;
	@Autowired
	private TransactionService transService;
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map,
			@RequestParam("customerId")String customerId,
			@RequestParam("customerPwd")String customerPwd,HttpSession session) {
		
		Integer custId=Integer.parseInt(customerId);
		if(loginService.validateLogin(custId, customerPwd))
		{
			
			session.setAttribute("custId", custId);
			String custName=loginService.getCustomerName(custId);
			map.put("custName", custName);
			return "mainPage";
		}
		return "redirect:/";
	}
	

	@RequestMapping("/createAccount")
	public String CreateAccount(ModelMap map) {
		map.put("account", new Account());
		return "createPage";
	}
	
	
	@PostMapping("/saveAccount")
	public String saveAccount(HttpSession session,
			@ModelAttribute("account") Account account) {
		account.setOpeningDate(new Date());
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer=loginService.findCustomer(customerId);
		
		account.setStatus("active");
		account.setCustomer(customer);
		acctService.createAccount(account);
		
		return "redirect:createAccount";
	}
	
	@RequestMapping("/showBalance")
	public String showBalancePage(ModelMap map,HttpSession session) {
		Integer custId=Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> accounts=acctService.getAccountWithBal(custId);
		map.put("accounts", accounts);
		return "showBalance";
	}
	@RequestMapping("/deposit")
	public String depositPage(ModelMap map,HttpSession session) {
		Integer custId = Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> accounts = acctService.getAllAccounts(custId);
		map.put("transaction", new Transaction());
		map.put("accounts", accounts);
		return "depositPage";
	}
	@RequestMapping("/withdraw")
	public String withdrawPage() {
		return "withdrawPage";
	}
	@RequestMapping("/doTransactions")
	public String doTransactions(@RequestParam("fromAcc")int accountId,@ModelAttribute("transaction")Transaction transaction,HttpSession session) {
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer= loginService.findCustomer(customerId);
		/*Customer customer=new Customer();
		customer.setCustomerId(customerId);*/
		transaction.setCustomer(customer);
		transaction.setTransactionDate(new Date());
		transaction.setStatus("Success");
		Account fromaccount = acctService.findAccount(accountId);
		transaction.setFromAccount(fromaccount);
		transaction.setToAccount(null);
		
		transService.createTransaction(transaction);
		
		return "redirect:/deposit";
	}
	@RequestMapping("/fundTransfer")
	public String fundTransferPage(ModelMap map,HttpSession session) {
		
		Integer custId = Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> accounts = acctService.getAllAccounts(custId);
		map.put("fundtransfer", new Transaction());
		map.put("accounts", accounts);
		List<Account> allaccounts = acctService.getremAccounts(custId);
		map.put("allaccounts", allaccounts);
		return "fundTransfer";
	}
	
	@RequestMapping("/doTransfer")
	public String doTransfer(@RequestParam("fromAcc")int fromAccId,@RequestParam("toAcc")int toAccId,@ModelAttribute("fundtransfer")Transaction fundtransfer,HttpSession session) {
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer= loginService.findCustomer(customerId);
		fundtransfer.setCustomer(customer);
		fundtransfer.setTransactionDate(new Date());
		fundtransfer.setStatus("Success");
		fundtransfer.setTransactionType("debit");
		Account fromaccount = acctService.findAccount(fromAccId);
		fundtransfer.setFromAccount(fromaccount);
		Account toaccount = acctService.findAccount(toAccId);
		fundtransfer.setToAccount(toaccount);
		
		transService.fundTransfer(fundtransfer);
		return "redirect:/fundTransfer";
	}
	@RequestMapping("/transactionSummary")
	public String transactionSummaryPage(HttpSession session,ModelMap map) {
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		List<Transaction> transactions=transService.printTransactions(customerId);
		map.put("transDate", transactions);
		map.put("listoftrans", null);
		return "transactionSummary";
	}
	
	@RequestMapping("/printTransaction")
	public String transsummary(
			@RequestParam("date1")String date1,
			@RequestParam("date2")String date2,
			HttpSession session,ModelMap map) throws ParseException {
		
		System.out.println(date1);
		System.out.println(date2);
		
		Date d1=new SimpleDateFormat("yyyy-MM-dd").parse(date1);
		Date d2=new SimpleDateFormat("yyyy-MM-dd").parse(date2);	
		
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		List<Transaction> transaction=transService.printDatedTransactions(customerId,d1,d2);
		List<Transaction> transactionDates=transService.printTransactions(customerId);
		
		map.put("listoftrans", transaction);
		map.put("transDate", transactionDates);
		
		return "transactionSummary";
	}
	@RequestMapping("/logout")
	public String logoutPage(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
}




