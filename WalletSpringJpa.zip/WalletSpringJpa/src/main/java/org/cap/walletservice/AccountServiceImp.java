package org.cap.walletservice;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.walletdao.AccountDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("acctService")
public class AccountServiceImp implements AccountService{
	@Autowired
	private AccountDao acctDao;
	@Override
	public void createAccount(Account account) {
	
		acctDao.createAccount(account);
		
	}
	@Override
	public List<Account> getAccountWithBal(int custId) {
		String str1="from Transaction trans where trans.customer.customerId=:custId and trans.transactionType='debit'";
		Map<Account, Double> deMap = acctDao.getAmout(str1,custId);

	String str2="from Transaction trans where trans.customer.customerId=:custId and trans.transactionType='credit'";
	Map<Account, Double> crMap = acctDao.getAmout(str2,custId);
		

	List<Account> accounts=getAllAccounts(custId);
	
	Iterator<Account> iterator= accounts.iterator();
	while(iterator.hasNext()) {
		Account account=iterator.next();
		double balance=0;
		double crAmt=0,deAmt=0;
		account.setUpdateBal(0);
		
		if(crMap.get(account) ==null)
			crAmt=0;
		else
			crAmt=crMap.get(account);
		

		if( deMap.get(account) ==null)
			deAmt=0;
		else
			deAmt= deMap.get(account);
		
		
		
		balance=account.getOpeningBalance() +
				crAmt-deAmt;
		
		account.setUpdateBal(balance);
		
	}
	
	
	return accounts;
	
	
}
	@Override
	public List<Account> getAllAccounts(int custId) {
		
		return acctDao.getAllAccounts(custId);
	}
	@Override
	public List<Account> getremAccounts(int custId) {
		// TODO Auto-generated method stub
		return acctDao.getremAccounts(custId);
	}
	@Override
	public Account findAccount(int fromAccId) {
		// TODO Auto-generated method stub
		return acctDao.findAccount(fromAccId);
	}
	
	

}
