package org.cap.walletservice;

import org.cap.model.Customer;
import org.cap.walletdao.LoginDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImp implements LoginService {
	@Autowired
	private LoginDao loginDao;
	@Override
	public boolean validateLogin(int customerId, String customerPwd) {
		// TODO Auto-generated method stub
		return loginDao.validateLogin(customerId, customerPwd);
	}

	@Override
	public String getCustomerName(int custId) {
		// TODO Auto-generated method stub
		return loginDao.getCustomerName(custId);
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return loginDao.findCustomer(customerId);
	}

}
