package org.cap.walletservice;

import org.cap.model.Customer;

public interface LoginService {
	public boolean validateLogin(int customerId,String customerPwd);

	public String getCustomerName(int custId);

	public Customer findCustomer(int customerId);
}
