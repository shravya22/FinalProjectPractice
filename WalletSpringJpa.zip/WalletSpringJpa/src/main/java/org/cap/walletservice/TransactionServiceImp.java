package org.cap.walletservice;

import java.util.Date;
import java.util.List;

import org.cap.model.Transaction;
import org.cap.walletdao.TransactionDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("transService")
public class TransactionServiceImp implements TransactionService{
	@Autowired
	private TransactionDao transDao;
	@Override
	public void createTransaction(Transaction transaction) {
		transDao.createTransaction(transaction);
		
	}
	@Override
	public List<Transaction> printTransactions(Integer customerId) {
		// TODO Auto-generated method stub
		return transDao.printTransactions(customerId);
	}
	@Override
	public void fundTransfer(Transaction transfer) {
		// TODO Auto-generated method stub
		transDao.fundTransfer(transfer);
	}
	@Override
	public List<Transaction> printDatedTransactions(Integer customerId, Date d1, Date d2) {
		// TODO Auto-generated method stub
		return transDao.printDatedTransactions(customerId,d1,d2);
	}
}
