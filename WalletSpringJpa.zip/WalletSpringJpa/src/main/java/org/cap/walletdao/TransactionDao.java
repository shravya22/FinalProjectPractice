package org.cap.walletdao;

import java.util.Date;
import java.util.List;

import org.cap.model.Transaction;

public interface TransactionDao {

	public void createTransaction(Transaction transaction);

	public List<Transaction> printTransactions(Integer customerId);

	public void fundTransfer(Transaction transfer);

	public List<Transaction> printDatedTransactions(Integer customerId, Date d1, Date d2);

}
