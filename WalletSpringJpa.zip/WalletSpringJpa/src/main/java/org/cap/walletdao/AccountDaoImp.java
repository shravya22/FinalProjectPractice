package org.cap.walletdao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;


import org.cap.model.Account;
import org.cap.model.Transaction;
import org.cap.walletservice.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("acctDao")

public class AccountDaoImp implements AccountDao{
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager entitymanager;
	@Autowired
	private LoginService loginService;
	@Override
	public void createAccount(Account account) {
Query query= entitymanager.createQuery("select max(accountNo) from Account");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNo(max.get(0)+1);
		
		System.out.println(account);
		
		entitymanager.persist(account);
		
	}
	@Override
	@Transactional(readOnly=true)
	public Map<Account, Double> getAmout(String str, int custId) {
		Query query2=entitymanager
				.createQuery(str);
		
		query2.setParameter("custId", custId);
		
		List<Transaction> transactions=query2.getResultList();
		Map<Account, Double> map=
		transactions.stream()
				.collect(
				Collectors.groupingBy(Transaction::getFromAccount,
					Collectors.summingDouble(Transaction::getAmount))
				);
		return map;
	}
	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllAccounts(int customerId) {

		Query query= entitymanager
			.createQuery("from Account acct where acct.customer.customerId=:custId");
		
		query.setParameter("custId", customerId);
		
		
		List<Account> accounts= query.getResultList();
		
		
		return accounts;
	}
	@Override
	@Transactional(readOnly=true)
	public List<Account> getremAccounts(int custId) {
		Query query= entitymanager
				.createQuery("from Account acct where acct.customer.customerId!=:custId");
			
			query.setParameter("custId", custId);
			
			
			List<Account> allaccounts= query.getResultList();
			
			
			return allaccounts;
	}
	@Override
	public Account findAccount(int accId) { 
			
				Account account=entitymanager.find(Account.class, accId);
				
				return account;
			} 
	
}
