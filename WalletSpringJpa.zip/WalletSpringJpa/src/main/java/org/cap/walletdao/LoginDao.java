package org.cap.walletdao;

import org.cap.model.Customer;

public interface LoginDao {
public boolean validateLogin(int customerId,String customerPwd);

public String getCustomerName(int custId);

public Customer findCustomer(int customerId);
}
