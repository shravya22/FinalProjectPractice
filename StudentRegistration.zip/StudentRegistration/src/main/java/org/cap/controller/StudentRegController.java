package org.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentRegController {
   @RequestMapping("/")
   public String StudentDetails() {
	return "PersonalDetails";
	   
   }
   @RequestMapping("/payment")
   public String PaymentDetails() {
	return "Payment";
	   
   }
   @RequestMapping("/success")
   public String SuccessMsg() {
	return "Success";
	   
   }
	
}
