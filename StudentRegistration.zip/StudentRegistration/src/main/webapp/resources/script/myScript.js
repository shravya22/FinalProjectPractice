
function validateForm(){
	var first=myform.firstname.value;
	var freg=/^[A-Z][a-zA-Z]{2,}/;
	var last=myform.lastname.value;
	var add1=myform.address.value;
	var mobileNo=myform.mobile.value;
	var radios = document.getElementsByName("r");
	var reg=/^\d{10}$/;
	var flag=false;
	if(first==""||first==null){
		flag=false;
		
		alert("*Please enter First Name");
	}
	else if(!freg.test(first)){
		flag=false;
		
		
		alert("*Enter valid first name");
	}
	else if(last==""||last==null){
		flag=false;
	/*	document.getElementById('fname').innerHTML="";*/
		
		alert("*Please enter Last Name");
	}
	else if(!freg.test(last)){
		flag=false;
		
		
		alert("*Enter valid last name");
	}
	else if(add1==""||add1==null){
		flag=false;
		
		
		alert("*Please enter Address");
	}
	 else if (radios[0].checked == false && radios[1].checked == false ) {
		 flag=false;
         
                alert(" * Select Gender");
         }
	else if(mobileNo==""||mobileNo==null){
		flag=false;
		
		
		alert("*Please enter Mobile Number");
	}
	else if(!reg.test(mobileNo)){
		flag=false;
		
		
		alert("*Mobile Number Should be 10 digits");
	}
	else{
		flag=true;
		alert("Personal Details are validated successfully");
      
		
	}
	
	
	return flag;
}




function paymentValidate(){
	var cardholder=pform.chname.value;
	var cardReg=/^[A-Z]+$/;
	var dcNumber=pform.cnumber.value;
	var cvv=pform.cvvnumber.value;
	var date=pform.edate.value;
	var dreg=/(0?[1-9]|1[012])[\/\-]\d{2}$/;
	//var fdate=new Date(date);
	//var cdate=new Date();
	//cdate.toString("MM yy");
	//var ccdate=Date.parse(cdate).toString("MM yy");
	var reg=/^\d{16}$/;
	var reg1=/^\d{3}$/;
	
	var flag=false;
	if(cardholder==""||cardholder==null){
		flag=false;
		
		alert("*Please enter card holder name");
	}
	else if(!cardReg.test(cardholder)){
		flag=false;
		
		
		alert("*Enter name in block letters");
	}
	
	else if(dcNumber==""||dcNumber==null){
		flag=false;
	
		
		alert("*Please enter Debit/Credit Number");
	}
	else if(!reg.test(dcNumber)){
		flag=false;
		
		
		alert("*Card Number Should be 16 digits");
	}
	else if(cvv==""||cvv==null){
		flag=false;
		
		
		alert("*Please enter CVV Number");
	}
	else if(!reg1.test(cvv)){
		flag=false;
		
		
		alert("*CVV Number Should be 3 digits");
	}
	
	else if(date==""||date==null){
		flag=false;
		
		
		alert("*Please enter Expiry date");
	}
	else if(!dreg.test(date)){
		flag=false;
		
		
		alert("*Enter valid date");
	}
	
	
	else{
		flag=true;
		
      
		alert("Payment Details are validated successfully");
	}
	
	return flag;
}
