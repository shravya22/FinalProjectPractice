package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class StudentRegBean {
	WebDriver driver;
	
	
	@FindBy(name="firstname",how=How.NAME)
	private WebElement firstName;
	
	@FindBy(name="lastname",how=How.NAME)
	private WebElement lastName;
	
	@FindBy(name="address",how=How.NAME)
	private WebElement addressDetails;
	
	@FindBy(name="city",how=How.NAME)
	private WebElement cityDetails;
	
	
	@FindBy(name="state",how=How.NAME)
	private WebElement stateDetails;
	
	
	@FindBy(name="r",how=How.NAME)
	private WebElement gender;
	
	@FindBy(name="course",how=How.NAME)
	private WebElement courseDetails;
	
	
	@FindBy(name="mobile",how=How.NAME)
	private WebElement mobileNo;
	
	@FindBy(name="next",how=How.NAME)
	private WebElement nextBtn;
	
	public StudentRegBean(WebDriver driver) {
		this.driver=driver;
		
		//extra
	   PageFactory.initElements(driver, this);
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public void setFirstName(String fName) {
		//driver.findElement(userName).sendKeys(usrName);
		firstName.sendKeys(fName);
	}
	

	public void setLastName(String lName) {
		//driver.findElement(userName).sendKeys(usrName);
		lastName.sendKeys(lName);
	}

	

	public void setAddressDetails(String add) {
		//driver.findElement(userName).sendKeys(usrName);
		addressDetails.sendKeys(add);
	}


	public void setCityDetails(String city) {
		//driver.findElement(userName).sendKeys(usrName);
		cityDetails.sendKeys(city);
	}
	public void setStateDetails(String state) {
		//driver.findElement(userName).sendKeys(usrName);
		stateDetails.sendKeys(state);
	}

	public void setGender(String g) {
		//driver.findElement(userName).sendKeys(usrName);
		/*gender.sendKeys(g);*/
		WebElement ele=driver.findElement(By.id(g));
		ele.click();
	}

	

	public void setCourseDetails(String course) {
		courseDetails.sendKeys(course);
	}

	

	public void setMobileNo(String mobile) {
		mobileNo.sendKeys(mobile);
	}

	

	public void setNextBtn() {
		
		nextBtn.submit();
	}
	
	public void loginToNextPage(String fName,String lName, String add,String city,
			                    String state,String gender,String course,String mobile) {
		this.setFirstName(fName);
		this.setLastName(lName);
		this.setAddressDetails(add);
		this.setCityDetails(city);
		this.setStateDetails(state);
		this.setGender(gender);
		this.setCourseDetails(course);
		this.setMobileNo(mobile);
		this.setNextBtn();
	}

	

}
