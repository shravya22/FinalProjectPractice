package StudentReg;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;


import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Page.StudentRegBean;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private StudentRegBean studentRegBean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		 driver=new ChromeDriver();
		 studentRegBean=new StudentRegBean(driver);
	} 
	@Given("^student registration$")
	public void student_registration() throws Throwable {
		driver.get("http://localhost:8081/StudentRegistration/");
	}

	@When("^valid student details$")
	public void valid_student_details() throws Throwable {
		studentRegBean.loginToNextPage("Tom", "Jerry", "MIPL", "Chennai", "Tamilnadu", "m", "B.Tech", "1234567890");
	    
	}

	@Then("^navigate to next page$")
	public void navigate_to_next_page() throws Throwable {
		driver.switchTo().alert().accept();
		
		String url=driver.getCurrentUrl();
		assertTrue(url.equals("http://localhost:8081/StudentRegistration/payment"));
		
	}



}
