package PaymentDetails;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Page.PaymentDetailsBean;
import Page.StudentRegBean;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef1 {
	private WebDriver driver;
	private PaymentDetailsBean paymentDetailsBean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		 driver=new ChromeDriver();
		 paymentDetailsBean=new PaymentDetailsBean(driver);
	} 
	@Given("^open payment details form$")
	public void open_payment_details_form() throws Throwable {
		driver.get("http://localhost:8081/StudentRegistration/payment");
	   
	}

	@When("^valid payment details$")
	public void valid_payment_details() throws Throwable {
		paymentDetailsBean.loginToNextPage("TOM","1234567891234567","123","11/25");
	}

	@Then("^register successfully$")
	public void register_successfully() throws Throwable {
		driver.switchTo().alert().accept();
		String url=driver.getCurrentUrl();
		assertTrue(url.equals("http://localhost:8081/StudentRegistration/success"));
	}

}
